{
	public function get_all()
    {
        return $this->db->from('feedbacks')->get()->result_array();
    }

    public function get($id)
    {
        return $this->db->from('feedbacks')->where('feedback_id', $id)->get()->result_array()[0];
    }
	
	public function get_user_lastname($users_id) {
        return $this->users_model->get($users_id)["user_lastname"];
    }
	
	public function get_user_firstname($users_id) {
        return $this->users_model->get($users_id)["user_firstname"];
    }

    public function create($feedback_type, $feedback_title, $feedback_description, $feedback_status, $feedback_resolution)
    {
        $this->db->insert('feedbacks', [
            "feedback_type" => $feedback_type,
            "feedback_title" => $feedback_title,
			"feedback_description" => $feedback_description,
			"feedback_status" => $feedback_status,
			"feedback_resolution" => $feedback_resolution
        ]);

    }

    public function update($id, $feedback_type, $feedback_title, $feedback_description, $feedback_status, $feedback_resolution)
    {
        $this->db->where("feedback_id", $id);
        $this->db->insert('feedbacks', [
            "feedback_type" => $feedback_type,
            "feedback_title" => $feedback_title,
			"feedback_description" => $feedback_description,
			"feedback_status" => $feedback_status,
			"feedback_resolution" => $feedback_resolution
        ]);
    }
}