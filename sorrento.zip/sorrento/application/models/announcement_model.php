<?php
	class announcement_model extends CI_Model
	{
		public function __construct()
		{
			parent::__construct();
			$this->load->database();
			$this->load->helper('url');
            $this->load->helper('date');
            date_default_timezone_set('Asia/Manila');
		}
		
		public function get_allAnnouncements()
		{
			return $this->db->from('announcements')->get()->result_array();
		}
		
		public function get_announcements()
		{
			return $this->db->from('announcements')->where('announcement_id', 1)->get()->result_array();
		}

		public function create_announcement (){
           $data = array(
                'announcement_user_id' => '1',
                'announcement_dateAdded' => mdate("%Y-%m-%d %H:%i:%s"),
                'announcement_subject' => $this->input->post('announcement_subject'),
                'announcement_details' => $this->input->post('announcement_details')
            );

            $this->db->insert('announcements', $data);
        }
	}
?>