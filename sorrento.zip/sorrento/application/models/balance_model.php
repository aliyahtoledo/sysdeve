<?php
	class balance_model extends CI_Model
	{
		public function __construct()
		{
			parent::__construct();
			$this->load->database();
			$this->load->helper('url');
		}
		
		public function get_userBalance()
		{
			return $this->db->from('balances')->where('balance_user_id', 1)->get()->result_array();
		}
		
		public function add_balance()
		{
			$data = array(
				'balance_user_id' => 1,
				'balance_unpaidMonths' => 3
			);
				
			$this->db->insert('balance', $data);
		}
	}
?>