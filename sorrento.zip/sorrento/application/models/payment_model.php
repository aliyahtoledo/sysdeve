<?php
	class payment_model extends CI_Model
	{
		public function __construct()
		{
			parent::__construct();
			$this->load->database();
			$this->load->helper('url');
		}
		
		public function get_userFeePayments()
		{
			return $this->db->from('payments')->where('payment_type', 'Membership Fee')->where('payment_user_id', 1)->get()->result_array();
		}
	}
?>
