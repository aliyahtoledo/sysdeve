<?php
	class user_model extends CI_Model
	{
		public function __construct()
		{
			parent::__construct();
			$this->load->database();
			$this->load->helper('url');
		}
		
		public function get_allActiveUsers()
		{
			return $this->db->from('users')->where('user_isActive', 1)->get()->result_array();
		}
		
		public function get_allHouses()
		{
			return $this->db->query('SELECT user_block, user_lot, user_type, user_firstName, user_lastName FROM users WHERE user_isActive = 1')->result_array();
		}
		
		public function get_user()
		{
			return $this->db->from('users')->where('user_id', 1)->get()->result_array();
		}
		
		public function create_user()
		{
			$data = array(
				'user_firstName' => $this->input->post('first_name'),
				'user_lastName' => $this->input->post('last_name'),
				'user_nationality' => $this->input->post('pw'),
				'user_birthday' => $this->input->post('birthday'),
				'user_profession' => $this->input->post('profession'),
				'user_moveIn' => $this->input->post('move_in'),
				'user_block' => $this->input->post('block'),
				'user_lot' => $this->input->post('lot'),
				'user_street' => $this->input->post('street'),
				'user_type' => $this->input->post('type'),
				'user_prevAdd' => $this->input->post('prev_add'),
				'user_telNo' => $this->input->post('tel_no'),
				'user_mobileNo' => $this->input->post('mobile_no'),
				'user_email' => $this->input->post('email'),
				'user_accountType' => 3,
				'user_username' => $this->input->post('username'),
				'user_password' => $this->input->post('pw'),
				'user_isActive' => 1
			);
				
			$this->db->insert('users', $data);
		}
	}
?>