<?php
	class sticker_model extends CI_Model
	{
		public function __construct()
		{
			parent::__construct();
			$this->load->database();
		}
		
		public function get_allApplications()
		{
			return $this->db->from('stickers')->where('sticker_number', NULL)->get()->result_array();
		}
		
		public function add_newVehicle()
		{
			$data = array(
				'sticker_user_id' => 1,
				'sticker_driver' => $this->input->post('driver_name'),
				'sticker_plateNo' => $this->input->post('plate_no'),
				'sticker_type' => $this->input->post('type')
				);
				
			$this->db->insert('stickers', $data);
		}
	}
?>