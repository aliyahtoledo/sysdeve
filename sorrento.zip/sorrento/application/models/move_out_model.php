<?php
	class move_out_model extends CI_Model
	{
		public function __construct()
		{
			parent::__construct();
			$this->load->database();
			$this->load->helper('url');
		}
		
		public function get_allDates()
		{
			return $this->db->from('move_out')->get()->result_array();
		}
		
		public function add_newDate()
		{
			$data = array(
				'move_out_user_id' => 1,
				'move_out_date' => $this->input->post('move_out_date'),
				'move_out_certificate' => $this->input->post('request_certificate')
			);
				
			$this->db->insert('move_out', $data);
		}
	}
?>