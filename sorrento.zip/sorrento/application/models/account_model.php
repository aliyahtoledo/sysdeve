<?php
	class acadz_model extends CI_Model
	{
	
		public function get_all()
		{
			return $this->db->from('account')->get()->result_array();
		}

		public function get($id)
		{
			return $this->db->from('account')->where('account_user_id', $id)->get()->result_array()[0];
		}
		
		public function get_user_type($username)
		{
			return $this->db->from('account')->where('account_username', $username)->get('account_user_type');
		}
		
		public function get_user_lastname($users_id) {
			return $this->users_model->get($users_id)["user_lastname"];
		}
		
		public function get_user_firstname($users_id) {
			return $this->users_model->get($users_id)["user_firstname"];
		}

		public function create($account_username, $account_password, $account_user_type)
		{
			$this->db->insert('account', [
				"account_username" => $account_username,
				"account_password" => $account_password,
				"account_user_type" => $account_user_type
			]);

		}

		public function update($id, $account_username, $account_password, $account_user_type)
		{
			$this->db->where("account_user_id", $id);
			$this->db->insert('account', [
				"account_username" => $account_username,
				"account_password" => $account_password,
				"account_user_type" => $account_user_type
			]);
		}
}
?>