<?php
	class household_member_model extends CI_Model
	{
		public function __construct()
		{
			parent::__construct();
			$this->load->database();
		}
		
		public function get_member()
		{
			return $this->db->from('household_members')->where('household_user_id', 1)->get()->result_array();
		}
		
		public function create_householdMember()
		{
			$data = array(
				'household_user_id' => 2,
				'household_name' => $this->input->post('member1'),
				'household_birthday' => $this->input->post('birthday1'),
				'household_profession' => $this->input->post('profession1'),
				'household_relation' => $this->input->post('relation1')
				);
				
			$this->db->insert('household_members', $data);
		}
	}
?>