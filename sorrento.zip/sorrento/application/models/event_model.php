<?php
	class event_model extends CI_Model
	{
		public function __construct()
		{
			parent::__construct();
			$this->load->database();
			$this->load->helper('url');
            $this->load->helper('date');
            date_default_timezone_set('Asia/Manila');
		}
		
		public function get_allEvents()
		{
			return $this->db->from('events')->get()->result_array();
		}
		
		public function get_events()
		{
			return $this->db->from('events')->where('event_id', 1)->get()->result_array();
		}
		public function create_event (){
            $data = array(
                'event_user_id' => '1',
                'event_dateAdded' => mdate("%Y-%m-%d %H:%i:%s"),
                'event_subject' => $this->input->post('event_subject'),
                'event_details' => $this->input->post('event_details'),
                'event_dateFrom' => $this->input->post('event_dateFrom'),
                'event_dateTo' => $this->input->post('event_dateTo')
            );
            $this->db->insert('events', $data);
        }
	}
?>