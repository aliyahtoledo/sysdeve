<?php
	class reservation_model extends CI_Model
	{
		public function __construct()
		{
			parent::__construct();
			$this->load->database();
			$this->load->helper('url');
		}
		
		public function get_courtReservations()
		{
			return $this->db->from('reservations')->where('reserve_type', 'Court')->get()->result_array();
		}
		
		public function add_courtReservation($court_time_from, $court_time_to)
		{
			$data = array(
				'reserve_user_id' => 1,
				'reserve_payment_id' => NULL,
				'reserve_type' => "Court",
				'reserve_date' => $this->input->post('date'),
				'reserve_timeFrom' => $court_time_from,
				'reserve_timeTo' => $court_time_to,
				'reserve_confirmed' => 0,
				'reserve_purpose' => $this->input->post('purpose')
			);
				
			$this->db->insert('reservations', $data);
		}
		
		public function get_clubhouseReservations()
		{
			return $this->db->from('reservations')->where('reserve_type', 'Clubhouse')->get()->result_array();
		}
		
		public function add_clubhouseReservation($club_time_from, $club_time_to)
		{
			$data = array(
				'reserve_user_id' => 1,
				'reserve_payment_id' => NULL,
				'reserve_type' => "Clubhouse",
				'reserve_date' => $this->input->post('club_date'),
				'reserve_timeFrom' => $club_time_from,
				'reserve_timeTo' => $club_time_to,
				'reserve_confirmed' => 0,
				'reserve_purpose' => $this->input->post('club_purpose')
			);
				
			$this->db->insert('reservations', $data);
		}
	}
?>