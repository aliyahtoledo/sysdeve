{
	public function get_all()
    {
        return $this->db->from('meeting_agendas')->get()->result_array();
    }

    public function get($id)
    {
        return $this->db->from('meeting_agendas')->where('meeting_agenda_id', $id)->get()->result_array()[0];
    }
	
	public function get_user_lastname($users_id) {
        return $this->users_model->get($users_id)["user_lastname"];
    }
	
	public function get_user_firstname($users_id) {
        return $this->users_model->get($users_id)["user_firstname"];
    }

    public function create($meeting_agenda_detail, $meeting_agenda_timefrom, $meeting_agenda_timeto, $meeting_agenda_date, $meeting_agenda_location)
    {
        $this->db->insert('meeting_agendas', [
            "meeting_agenda_detail" => $meeting_agenda_detail,
            "meeting_agenda_timefrom" => $meeting_agenda_timefrom,
			"meeting_agenda_timeto" => $meeting_agenda_timeto,
			"meeting_agenda_date" => $meeting_agenda_date,
			"meeting_agenda_location" => $meeting_agenda_location
        ]);

    }

    public function update($id, $meeting_agenda_detail, $meeting_agenda_timefrom, $meeting_agenda_timeto, $meeting_agenda_date, $meeting_agenda_location)
    {
        $this->db->where("meeting_agenda_id", $id);
        $this->db->insert('meeting_agendas', [
            "meeting_agenda_detail" => $meeting_agenda_detail,
            "meeting_agenda_timefrom" => $meeting_agenda_timefrom,
			"meeting_agenda_timeto" => $meeting_agenda_timeto,
			"meeting_agenda_date" => $meeting_agenda_date,
			"meeting_agenda_location" => $meeting_agenda_location
        ]);
    }
}