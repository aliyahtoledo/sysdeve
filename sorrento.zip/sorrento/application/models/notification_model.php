<?php
	class notification_model extends CI_Model
	{
		public function __construct()
		{
			parent::__construct();
			$this->load->database();
			$this->load->helper('url');
		}
		
		public function get_allNotifications()
		{
			return $this->db->from('notifications')->get()->result_array();
		}
		
		public function get_notifications()
		{
			return $this->db->from('notifications')->where('notification_id', 1)->get()->result_array();
		}
	}
?>