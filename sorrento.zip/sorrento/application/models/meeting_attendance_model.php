{
	public function get_all()
    {
        return $this->db->from('meeting_attendance')->get()->result_array();
    }

    public function get($id)
    {
        return $this->db->from('meeting_attendance')->where('meeting_attendance_id', $id)->get()->result_array()[0];
    }
	
	public function get_meeting_agenda_id($meeting_agenda_id) {
        return $this->users_model->get($meeting_agenda_id);
    }

    public function create($meeting_confirmation, $meeting_available_date)
    {
        $this->db->insert('meeting_attendance', [
            "meeting_confirmation" => $meeting_confirmation,
            "meeting_available_date" => $meeting_available_date
        ]);

    }

    public function update($id, $meeting_confirmation, $meeting_available_date)
    {
        $this->db->where("meeting_attendance_id", $id);
        $this->db->insert('meeting_attendance', [
            "meeting_confirmation" => $meeting_confirmation,
            "meeting_available_date" => $meeting_available_date
        ]);
    }
}