<?php

/**
 *      
 * 
 *  @author          Edmandie Samonte        (edmandie.samonte@gmail.com)
 *  @copyright       2011 
 * 
 */

get_instance()->load->helper('url');


function rsrc($filename ='')
{
	return base_url(get_instance()->config->item("resources_dir")."/".$filename);
}

/**
 *
 * CSS url generator
 * 
 *  This function returns the link to the 
 *  given css file inside the resources folder.
 * 
 * @param   string    $filename       The filename of the css file including the extension
 * @return  string                    The CSS url
 */
function css( $filename = '' ){
    return base_url( get_instance()->config->item("resources_dir") . "/" . get_instance()->config->item("css_dir") . "/" . $filename );
}

/**
 *
 * Image url generator
 * 
 *  This function returns the link to the 
 *  given image file inside the resources folder.
 * 
 * @param   string    $filename       The filename of the image file including the extension
 * @return  string                    The Image url
 */
function img( $filename = '' ){
    return base_url( get_instance()->config->item("resources_dir") . "/" . get_instance()->config->item("images_dir") . "/" . $filename );
}
  /**
 *
 * Javascript url generator
 * 
 *  This function returns the link to the 
 *  given image file inside the resources folder.
 * 
 * @param   string    $filename       The filename of the image file including the extension
 * @return  string                    The Image url
 */
function js( $filename = '' ){
    return base_url( get_instance()->config->item("resources_dir") . "/" . get_instance()->config->item("js_dir") . "/" . $filename );
}


/* End of File */