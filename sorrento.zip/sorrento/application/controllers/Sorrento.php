<?php
class Sorrento extends CI_Controller {

	public function __construct()
	{
		parent::__construct();
		$this->load->helper('url_helper');
    	$this->load->helper('directory');
		$this->load->helper('form');
		$this->load->library('form_validation');
		$this->load->model('user_model');
		$this->load->model('household_member_model');
		$this->load->model('announcement_model');
		$this->load->model('reservation_model');
		$this->load->model('balance_model');
		$this->load->model('payment_model');
		$this->load->model('event_model');
		$this->load->model('sticker_model');
		$this->load->model('move_out_model');
	}
		
    public function index()
    {
        $this->load->view('login');
    }
	
	public function login()
    {
		$username = $this->form_validation->set_rules('username', 'Username', 'required');
		$pw = $this->form_validation->set_rules('pw', 'Password', 'required');
		$user = $this->input->post('username');

		if ($this->form_validation->run() === FALSE)
		{
			$this->load->view('login');

		}
		else if($user == 'homeowner' || $user == 'denisejamora')
		{
		$data['user_announcement'] = $this->announcement_model->get_allAnnouncements();
		$data['user_event'] = $this->event_model->get_allEvents();
			$this->load->view('user_dash', $data);
		}
		else if($user == 'admin')
		{
		$data['announce'] = $this->announcement_model->get_allAnnouncements();
		$data['event'] = $this->event_model->get_allEvents();
			$this->load->view('admin_dash', $data);
		}
		else if($user == 'board')
		{
			$this->load->view('board_dash');
		}
    }
	
	public function forgot_password()
    {
        $this->load->view('forgot_passowrd');
    }
	
	public function register()
    {
		$first_name = $this->form_validation->set_rules('first_name', 'First Name', 'required');
		$last_name = $this->form_validation->set_rules('last_name', 'Last Name', 'required');
		$nationality = $this->form_validation->set_rules('nationality', 'Nationality', 'required');
		$birthday = $this->form_validation->set_rules('birthday', 'Birthday', 'required');
		$profession = $this->form_validation->set_rules('profession', 'Profession', 'required');
		$move_in = $this->form_validation->set_rules('move_in', 'Move In', 'required');
		$block = $this->form_validation->set_rules('block', 'Block', 'required');
		$lot = $this->form_validation->set_rules('lot', 'Lot', 'required');
		$street = $this->form_validation->set_rules('street', 'Street', 'required');
		$type = $this->form_validation->set_rules('type', 'Type', 'required');
		$prev_add = $this->form_validation->set_rules('prev_add', 'Previous Address', 'required');
		$tel_no = $this->form_validation->set_rules('tel_no', 'Telephone No', 'required');
		$mobile_no = $this->form_validation->set_rules('mobile_no', 'Mobile No', 'required');
		$email = $this->form_validation->set_rules('email', 'Email', 'required');
		$username = $this->form_validation->set_rules('username', 'Username', 'required');
		$pw = $this->form_validation->set_rules('pw', 'Password', 'required');
		$retype = $this->form_validation->set_rules('retype', 'Retype', 'required|matches[pw]');

		if ($this->form_validation->run() === FALSE)
		{
			$this->load->view('register');

		}
		else
		{
			$this->user_model->create_user();
			$this->load->view('register2');
		}
    }
	
	public function register2()
    {
		$member1 = $this->form_validation->set_rules('member1', 'First Name', 'required');
		$birthday1 = $this->form_validation->set_rules('birthday1', 'Last Name', 'required');
		$profession1 = $this->form_validation->set_rules('profession1', '', 'required');
		$relation1 = $this->form_validation->set_rules('relation1', '', 'required');

		if ($this->form_validation->run() === FALSE)
		{
			$this->load->view('register2');
		}
		else
		{
			$this->household_member_model->create_householdMember();
			$this->load->view('login');
		}
    }
	
	
	//Homeowner or tenant functions
	public function user_announcement_page()
    {
        $data['announcement'] = $this->announcement_model->get_announcements();
		
		$this->load->view('user_announcement_page', $data);
    }
	
	public function user_announcements()
    {
        $data['announcements'] = $this->announcement_model->get_allAnnouncements();
		
        $this->load->view('user_announcements', $data);
    }
	
	public function user_clubhouse()
    {
        $data['reservations'] = $this->reservation_model->get_clubhouseReservations();
		
		$club_date = $this->form_validation->set_rules('club_date', 'Date', 'required');
		$club_purpose = $this->form_validation->set_rules('club_purpose', '', 'required');

		if ($this->form_validation->run() === FALSE)
		{
			$this->load->view('user_clubhouse', $data);
		}
		else
		{
			$club_time_from = ($this->input->post('club_time_from_hr').':'.$this->input->post('club_time_from_min').':'.'00');
			$club_time_to = ($this->input->post('club_time_to_hr').':'.$this->input->post('club_time_to_min').':'.'00');
			$this->reservation_model->add_clubhouseReservation($club_time_from, $club_time_to);
			$this->load->view('user_clubhouse', $data);
		}
    }
	
	public function user_court()
    {
        $data['reservations'] = $this->reservation_model->get_courtReservations();
		
		$court_date = $this->form_validation->set_rules('date', 'Date', 'required');
		$court_purpose = $this->form_validation->set_rules('purpose', '', 'required');

		if ($this->form_validation->run() === FALSE)
		{
			$this->load->view('user_court', $data);
		}
		else
		{
			$court_time_from = ($this->input->post('time_from_hr').':'.$this->input->post('time_from_min').':'.'00');
			$court_time_to = ($this->input->post('time_to_hr').':'.$this->input->post('time_to_min').':'.'00');
			$this->reservation_model->add_courtReservation($court_time_from, $court_time_to);
			$this->load->view('user_court', $data);
		}
    }
	
	public function user_dash()
    { 
		$data['user_announcement'] = $this->announcement_model->get_allAnnouncements();
		$data['user_event'] = $this->event_model->get_allEvents();
		
        $this->load->view('user_dash', $data);
    }
	
	public function user_dues()
    {
        $data['balances'] = $this->balance_model->get_userBalance();
        $data['payments'] = $this->payment_model->get_userFeePayments();
		
        $this->load->view('user_dues', $data);
    }
	
	public function user_event_page()
    {
        $data['events'] = $this->event_model->get_events();
		
		$this->load->view('user_event_page', $data);
    }
	
	public function user_events()
    {
        $data['events'] = $this->event_model->get_allEvents();
		
        $this->load->view('user_events', $data);
    }
	
	public function user_feedback()
    {
        $this->load->view('user_feedback');
    }
	
	public function user_profile()
    {
		$data['user'] = $this->user_model->get_user();
		$data['household_member'] = $this->household_member_model->get_member();
		
        $this->load->view('user_profile', $data);
    }
	
	public function user_vehicle_sticker()
    {
		$driver_name = $this->form_validation->set_rules('driver_name', 'Driver Name', 'required');
		$plate_no = $this->form_validation->set_rules('plate_no', 'Plate No', 'required');
		$type = $this->form_validation->set_rules('type', 'Sticker Type', 'required');

		if ($this->form_validation->run() === FALSE)
		{
			$this->load->view('user_vehicle_sticker');
		}
		else
		{
			$this->sticker_model->add_newVehicle();
			$this->load->view('user_vehicle_sticker');
		}
    }
	
	public function user_move_out()
    {
		$move_out_date = $this->form_validation->set_rules('move_out_date', 'Date', 'required');
		$request_certificate = $this->form_validation->set_rules('request_certificate', 'Request', 'required');

		if ($this->form_validation->run() === FALSE)
		{
			$this->load->view('user_move_out');
		}
		else
		{
			$this->move_out_model->add_newDate();
			$this->load->view('user_move_out');
		}
    }
	
	public function user_financial_report()
    {
        $this->load->view('user_financial_report');
    }
	
	//Admin functions
	public function admin_dash()
	{
		$data['announce'] = $this->announcement_model->get_allAnnouncements();
		$data['event'] = $this->event_model->get_allEvents();
		
        $this->load->view('admin_dash', $data);
    }
	
	public function admin_manage_reservations()
    {
        $this->load->view('admin_manage_reservations', $data);
    }
	
	public function admin_generate_financial_report()
    {
        $this->load->view('admin_generate_financial_report');
    }
	
	public function admin_collect_fees()
    {
        $this->load->view('admin_collect_fees');
    }
	
	public function admin_membership_directory()
    {
		$data['members'] = $this->user_model->get_allActiveUsers();
        $this->load->view('admin_membership_directory', $data);
    }
	
	public function admin_house_directory()
    {
		$data['houses'] = $this->user_model->get_allHouses();
        $this->load->view('admin_house_directory', $data);
    }
	
	public function admin_activate_account()
    {
        $this->load->view('admin_activate_account');
    }
	
	public function admin_membership_standing()
    {
        $this->load->view('admin_membership_standing');
    }
	
	public function admin_create_announcement(){
        $announcement_subject = $this->form_validation->set_rules('announcement_subject', 'Title', 'required');
        $announcement_details = $this->form_validation->set_rules('announcement_details', 'Description', 'required');

        if ($this->form_validation->run() === FALSE)
        {
            $this->load->view('admin_create_announcement');
        }
        else
        {   $this->load->model('announcement_model');
            $this->announcement_model->create_announcement();
            $this->load->view('admin_create_announcement');
        }
    }
	
	public function admin_create_meeting_agenda()
    {
        $this->load->view('admin_create_meeting_agenda');
    }
	
	public function admin_create_event()
    {
        $event_subject = $this->form_validation->set_rules('event_subject', 'Location', 'required');
        $event_details = $this->form_validation->set_rules('event_details', 'Description', 'required');
        $event_dateFrom = $this->form_validation->set_rules('event_dateFrom', 'From', 'required');
        $event_dateTo = $this->form_validation->set_rules('event_dateTo', 'To', 'required');


        if ($this->form_validation->run() === FALSE)
        {
            $this->load->view('admin_create_event');
        }
        else
        {
            $this->event_model->create_event();
            $this->load->view('admin_create_event');
        }

    }
	
	public function admin_vehicle_sticker()
    {
		$data['people'] = $this->user_model->get_allActiveUsers();
		$data['stickers'] = $this->sticker_model->get_allApplications();
        $this->load->view('admin_vehicle_sticker', $data);
    }
	
	public function admin_move_out_dates()
    {
		$data['homeowner'] = $this->user_model->get_allActiveUsers();
		$data['move_out'] = $this->move_out_model->get_allDates();
        $this->load->view('admin_move_out_dates', $data);
    }
	
	public function admin_feedback()
    {
        $this->load->view('admin_feedback');
    }
	
	public function admin_view_meeting_attendees()
    {
        $this->load->view('admin_view_meeting_attendees');
    }
	
	
	
	//board functions
	
	public function board_dash()
    {
        $this->load->view('board_dash');
    }
	
	public function board_confirm_attendance()
    {
        $this->load->view('board_confirm_attendance');
    }
	
	public function board_approve_financial_report()
    {
        $this->load->view('board_approve_financial_report');
    }
	
	public function board_announcements()
    {
        $this->load->view('board_announcements');
    }
	
	public function board_meeting_agenda()
    {
        $this->load->view('board_meeting_agenda');
    }
	
	public function board_events()
    {
        $this->load->view('board_events');
    }
	
	public function board_meeting_agenda_attendance()
    {
        $this->load->view('board_meeting_agenda_attendance');
    }
	
	public function board_feedback()
    {
        $this->load->view('board_feedback');
    }
}