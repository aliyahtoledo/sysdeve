<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');

/**
 *      
 * 
 *  @author          Edmandie Samonte        (edmandie.samonte@gmail.com)
 *  @copyright       2011 
 * 
 */

/**
 * 
 * Resources Directory Name
 * 
 *  The name of the static folder for resources like css, js and images.
 *  
 *  It is assumed that this folder is inside the directory that contains the index.php.
 * 
 *  NO TRAILING SLASH
 */
$config["resources_dir"]    = "rsrc";

/**
 *  Images Directory Name
 * 
 *  The name of the static folder for site images. This folder contains all images
 *  relevant to the website layout not on the data processing.
 * 
 *  It is assumed that this folder is inside the Resources Folder
 * 
 * NO TRAILING SLASH
 */
$config["images_dir"]       = "img";

/**
 *  CSS Directory Name
 * 
 *  The name of the static folder for site css.
 * 
 *  It is assumed that this folder is inside the Resources Folder
 * 
 * NO TRAILING SLASH
 */
$config["css_dir"]          = "css";

/**
 *  JavaScript Directory Name
 * 
 *  The name of the static folder for site css.
 * 
 *  It is assumed that this folder is inside the Resources Folder
 * 
 * NO TRAILING SLASH
 */
$config["js_dir"]           = "js";


?>
