<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">
  <title>Sorrento - Dashboard</title>
  <!-- Bootstrap core CSS-->
  <link href="<?php echo css('vendor/bootstrap/css/bootstrap.min.css'); ?>" rel="stylesheet">
  <!-- Custom fonts for this template-->
  <link href="<?php echo css('vendor/font-awesome/css/font-awesome.min.css'); ?>" rel="stylesheet" type="text/css">
  <!-- Custom styles for this template-->
  <link href="<?php echo css('sb-admin.css'); ?>" rel="stylesheet">
</head>

<body class="fixed-nav sticky-footer bg-dark" id="page-top">
<!-- Navigation-->
<!-- Navigation-->
<nav class="navbar navbar-expand-lg navbar-dark bg-dark fixed-top" id="mainNav">
    <a class="navbar-brand" href="index.html">Sorrento</a>
    <button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarResponsive">
        <ul class="navbar-nav navbar-sidenav" id="exampleAccordion">
            <li class="nav-item" data-toggle="tooltip" data-placement="right" title="Dashboard">
                <a class="nav-link" href="DashboardView.html">
                    <i class="fa fa-fw fa-dashboard"></i>
                    <span class="nav-link-text">Dashboard</span>
                </a>
            </li>
            <li class="nav-item" data-toggle="tooltip" data-placement="right" title="Menu Levels">
                <a class="nav-link nav-link-collapse collapsed" data-toggle="collapse" href="#collapseMulti" data-parent="#exampleAccordion">
                    <i class="fa fa-fw fa-cogs"></i>
                    <span class="nav-link-text">Board</span>
                </a>
                <ul class="sidenav-second-level collapse" id="collapseMulti">
                    <li>
                        <a href="tables.html">Membership Directory</a>
                    </li>
                    <li>
                        <a href="#">House Directory</a>
                    </li>
                    <li>
                        <a href="Create%20Event%20View.html">Confirm Meeting Attendance</a>
                    </li>
                    <li>
                        <a href="CreateAnnouncementView.html">Approve Announcements</a>
                    </li>
                    <li>
                        <a href="Create%20Event%20View.html">Approve Events</a>
                    </li>
                    <li>
                        <a href="Create%20Event%20View.html">Approve Meeting Agenda</a>
                    </li>
					<li>
                        <a href="ManageReservationsView.html">Approve Monthly Financial Report</a>
                    </li>
					<li>
                        <a class="nav-link-collapse collapsed" data-toggle="collapse" href="#collapseLodgers">Reports</a>
                        <ul class="sidenav-third-level collapse" id="collapseLodgers">
                            <li>
                                <a href="#">Financial</a>
                            </li>
                            <li>
                                <a href="#">Transaction</a>
                            </li>
                            <li>
                                <a href="#">Meeting Attendance</a>
                            </li>
                        </ul>
                    </li>
                </ul>
            </li>
            <li class="nav-item" data-toggle="tooltip" data-placement="right" title="Menu Levels">
                <a class="nav-link nav-link-collapse collapsed" data-toggle="collapse" href="#collapseHomeowner" data-parent="#exampleAccordion">
                    <i class="fa fa-fw fa-home"></i>
                    <span class="nav-link-text">Homeowner</span>
                </a>
                <ul class="sidenav-second-level collapse" id="collapseHomeowner">
                    <li>
                        <a class="nav-link" href="user_profile.html">
                            <span class="nav-link-text">Profile</span>
                        </a>
                    </li>
                    <li>
                        <a class="nav-link" href="user_announcements.html">
                            <span class="nav-link-text">Announcements</span>
                        </a>
                    </li>
					<li>
                        <a class="nav-link" href="user_announcements.html">
                            <span class="nav-link-text">Notifications</span>
                        </a>
                    </li>
					<li>
                        <a class="nav-link" href="user_announcements.html">
                            <span class="nav-link-text">Events</span>
                        </a>
                    </li>
                    <li>
                        <a class="nav-link" href="user_dues.html">
                            <span class="nav-link-text">Membership Dues</span>
                        </a>
                    </li>
                    <li class="nav-item" data-toggle="tooltip" data-placement="right" title="Vehicle Sticker">
                        <a class="nav-link" href="user_sticker.html">
                            <span class="nav-link-text">Vehicle Sticker</span>
                        </a>
                    </li>
                    <li>
                        <a class="nav-link-collapse collapsed" data-toggle="collapse" href="#collapseAmenities">Reserve Amenities</a>
                        <ul class="sidenav-third-level collapse" id="collapseAmenities">
                            <li>
                                <a href="#">Clubhouse</a>
                            </li>
                            <li>
                                <a href="#">Court</a>
                            </li>
                        </ul>
                    </li>
                    <li class="nav-item" data-toggle="tooltip" data-placement="right" title="Vehicle Sticker">
                        <a class="nav-link" href="user_sticker.html">
                            <span class="nav-link-text">Move Out Form</span>
                        </a>
                    </li>
                    <li>
                        <a class="nav-link-collapse collapsed" data-toggle="collapse" href="#collapseLodgers">Reports</a>
                        <ul class="sidenav-third-level collapse" id="collapseLodgers">
                            <li>
                                <a href="#">Financial</a>
                            </li>
                            <li>
                                <a href="#">Transaction</a>
                            </li>
                            <li>
                                <a href="#">Meeting Attendance</a>
                            </li>
                            <li>
                                <a href="#">Sticker Acquisitions</a>
                            </li>
                            <li>
                                <a href="#">Reservations</a>
                            </li>
                        </ul>
                    </li>
					<li class="nav-item" data-toggle="tooltip" data-placement="right" title="Vehicle Sticker">
                        <a class="nav-link" href="user_sticker.html">
                            <span class="nav-link-text">Feedback</span>
                        </a>
                    </li>
                </ul>
            </li>
        </ul> <!-- End of Navigation -->
        <ul class="navbar-nav sidenav-toggler">
            <li class="nav-item">
                <a class="nav-link text-center" id="sidenavToggler">
                    <i class="fa fa-fw fa-angle-left"></i>
                </a>
            </li>
        </ul>
        <ul class="navbar-nav ml-auto">
            <li class="nav-item">
                <form class="form-inline my-2 my-lg-0 mr-lg-2">
                    <div class="input-group">
                        <input class="form-control" type="text" placeholder="Search for...">
                        <span class="input-group-append">
                <button class="btn btn-primary" type="button">
                  <i class="fa fa-search"></i>
                </button>
              </span>
                    </div>
                </form>
            </li>
            <li class="nav-item">
                <a class="nav-link" data-toggle="modal" data-target="#exampleModal">
                    <i class="fa fa-fw fa-sign-out"></i>Logout</a>
            </li>
        </ul>
    </div>
</nav>
  <div class="content-wrapper">
    <div class="container-fluid">
      <!-- Breadcrumbs-->
      <ol class="breadcrumb">
        <li class="breadcrumb-item">
          <a href="<?php echo site_url('Sorrento/user_dash'); ?>">Dashboard</a>
        </li>
        
		<li class="breadcrumb-item active">Reports</li>
		<li class="breadcrumb-item active">Financial</li>
      </ol>
      <div class="row">
        <div class="col-12">
          <div class="card card-register mx-auto mt-5">
			<div class="card-header">
			  <i class="fa fa-table"></i> Financial Report</div>
			<div class="card-body">
			<p>Income</p>
			  <div class="row">
                <div class="col-sm-8 my-auto">
                  <div class="small">Total Fees Collected for the Month</div>
                </div>
                <div class="col-sm-4 text-center my-auto">
                  <div class="small text-muted">Php 173,178.00</div>
                </div>
              </div>
			  <br>
			  <div class="row">
                <div class="col-sm-8 my-auto">
                  <div class="small">Donations</div>
                </div>
                <div class="col-sm-4 text-center my-auto">
                  <div class="small text-muted">Php 273,178.00</div>
                </div>
              </div>
			  <br>
			  <div class="row">
                <div class="col-sm-8 my-auto">
                  <div class="small">Fundraising Collections</div>
                </div>
                <div class="col-sm-4 text-center my-auto">
                  <div class="small text-muted">Php 150,000.00</div>
                </div>
              </div>
			  <br>
			  <br>
			  <p>Expenses</p>
			  <div class="row">
                <div class="col-sm-8 my-auto">
                  <div class="small">Utilities</div>
                </div>
                <div class="col-sm-4 text-center my-auto">
                  <div class="small text-muted">Php 150,000.00</div>
                </div>
              </div>
			  <br>
			  <div class="row">
                <div class="col-sm-8 my-auto">
                  <div class="small">Maintenance</div>
                </div>
                <div class="col-sm-4 text-center my-auto">
                  <div class="small text-muted">Php 150,000.00</div>
                </div>
              </div>
			  <br>
			  <div class="row">
                <div class="col-sm-8 my-auto">
                  <div class="small">Security</div>
                </div>
                <div class="col-sm-4 text-center my-auto">
                  <div class="small text-muted">Php 150,000.00</div>
                </div>
              </div>
			  <br>
			  <div class="row">
                <div class="col-sm-8 my-auto">
                  <div class="small">Staff Salary</div>
                </div>
                <div class="col-sm-4 text-center my-auto">
                  <div class="small text-muted">Php 150,000.00</div>
                </div>
              </div>
			  <br>
			  <div class="row">
                <div class="col-sm-8 my-auto">
                  <div class="small">Garbage Collections</div>
                </div>
                <div class="col-sm-4 text-center my-auto">
                  <div class="small text-muted">Php 150,000.00</div>
                </div>
              </div>
			  <br>
			  <div class="row">
                <div class="col-sm-8 my-auto">
                  <div class="small">Others</div>
                </div>
                <div class="col-sm-4 text-center my-auto">
                  <div class="small text-muted">Php 150,000.00</div>
                </div>
              </div>
			  <br>
			  <br>
			  <br>
			  <br>
			  <div class="row">
                <div class="col-sm-8 my-auto">
                  <div class="small">Balance</div>
                </div>
                <div class="col-sm-4 text-center my-auto">
                  <div class="small"><strong>Php 23,178.00</strong></div>
                </div>
              </div>
			  <br><br>
			  <div class="form-group">
                <form>
					<a class="btn btn-primary btn-block" href="<?php echo site_url('Sorrento/user_court'); ?>" style="width: 40%; margin: auto;">Approve</a>
				</form>
              </div>
			  
            </div>
			</div>
			</div>
        </div>
      </div>
	  <br>
	  <br>
    </div>
    <!-- /.container-fluid-->
    <!-- /.content-wrapper-->
    <footer class="sticky-footer">
      <div class="container">
        <div class="text-center">
          <small>Copyright © Sorrento 2018</small>
        </div>
      </div>
    </footer>
    <!-- Scroll to Top Button-->
    <a class="scroll-to-top rounded" href="#page-top">
      <i class="fa fa-angle-up"></i>
    </a>
    <!-- Logout Modal-->
    <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
      <div class="modal-dialog" role="document">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title" id="exampleModalLabel">Ready to Leave?</h5>
            <button class="close" type="button" data-dismiss="modal" aria-label="Close">
              <span aria-hidden="true">×</span>
            </button>
          </div>
          <div class="modal-body">Select "Logout" below if you are ready to end your current session.</div>
          <div class="modal-footer">
            <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
            <a class="btn btn-primary" href="login.html">Logout</a>
          </div>
        </div>
      </div>
    </div>
    <!-- Bootstrap core JavaScript-->
  <script src="<?php echo js('vendor/jquery/jquery.min.js'); ?>"></script>
  <script src="<?php echo css('vendor/bootstrap/js/bootstrap.bundle.min.js'); ?>"></script>
  <!-- Core plugin JavaScript-->
  <script src="<?php echo js('vendor/jquery-easing/jquery.easing.min.js'); ?>"></script>
  <script src="<?php echo js('sb-admin.js'); ?>"></script>
</body>

</html>
