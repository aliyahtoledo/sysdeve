<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">
  <title>Sorrento - Register</title>
  <!-- Bootstrap core CSS-->
  <link href="<?php echo css('vendor/bootstrap/css/bootstrap.min.css'); ?>" rel="stylesheet">
  <!-- Custom fonts for this template-->
  <link href="<?php echo css('vendor/font-awesome/css/font-awesome.min.css'); ?>" rel="stylesheet" type="text/css">
  <!-- Custom styles for this template-->
  <link href="<?php echo css('sb-admin.css'); ?>" rel="stylesheet">
</head>

<body class="bg-dark">
  <div class="container">
    <div class="card card-register mx-auto mt-5">
      <div class="card-header">Move In Form</div>
      <div class="card-body">
        <form action="<?php echo site_url('Sorrento/register2'); ?>" method="post">
		  <div class="form-group">
                <label for="householdMember">Household Members</label>
				<select class="form-control" id="householdMember" name="householdMember" onclick="addMembers()">
					<option value="0">Please Select</option>
					<option value="1">1</option>
					<option value="2">2</option>
					<option value="3">3</option>
					<option value="4">4</option>
					<option value="5">5</option>
					<option value="6">6</option>
					<option value="7">7</option>
				</select>
          </div>
		  <div class="form-group">
            <div class="form-row" id="row">
              <div class="col-md-6" id="container1">
              </div>
              <div class="col-md-6" id="container2">
              </div>
            </div>
          </div>
		  <br><br>
          <input id="submit" class="btn btn-primary btn-block" type="submit" name="submit" value="Register">
        </form>
        <div class="text-center">
          <a class="d-block small mt-3" href="<?php echo site_url('Sorrento/index'); ?>">Login Page</a>
        </div>
      </div>
    </div>
  </div>
  <br>
  <!-- Bootstrap core JavaScript-->
  <script src="<?php echo js('vendor/jquery/jquery.min.js'); ?>"></script>
  <script src="<?php echo css('vendor/bootstrap/js/bootstrap.bundle.min.js'); ?>"></script>
  <!-- Core plugin JavaScript-->
  <script src="<?php echo js('vendor/jquery-easing/jquery.easing.min.js'); ?>"></script>
  <script src="<?php echo js('sb-admin.js'); ?>"></script>
</body>

</html>
