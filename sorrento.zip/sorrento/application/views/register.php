<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">
  <title>Sorrento - Register</title>
  <!-- Bootstrap core CSS-->
  <link href="<?php echo css('vendor/bootstrap/css/bootstrap.min.css'); ?>" rel="stylesheet">
  <!-- Custom fonts for this template-->
  <link href="<?php echo css('vendor/font-awesome/css/font-awesome.min.css'); ?>" rel="stylesheet" type="text/css">
  <!-- Custom styles for this template-->
  <link href="<?php echo css('sb-admin.css'); ?>" rel="stylesheet">
</head>

<body class="bg-dark">
  <div class="container">
    <div class="card card-register mx-auto mt-5">
      <div class="card-header">Move In Form</div>
      <div class="card-body">
        <form action="<?php echo site_url('Sorrento/register'); ?>" method="post">
          <div class="form-group">
            <div class="form-row">
              <div class="col-md-6">
                <label for="exampleInputName">First name</label>
                <input class="form-control" id="first_name" type="text" name="first_name" aria-describedby="nameHelp" placeholder="Enter First Name">
				<div style="color: red; margin-bottom: 0; margin-top: 0.5em"><?php echo form_error('first_name'); ?></div>
              </div>
              <div class="col-md-6">
                <label for="exampleInputLastName">Last name</label>
                <input class="form-control" id="last_name" type="text" name="last_name" aria-describedby="nameHelp" placeholder="Enter Last Name">
				<div style="color: red; margin-bottom: 0; margin-top: 0.5em"><?php echo form_error('last_name'); ?></div>
              </div>
            </div>
          </div>
		  <div class="form-group">
            <div class="form-row">
              <div class="col-md-6">
                <label for="exampleInputNationality">Nationality</label>
                <input class="form-control" id="nationality" type="text" name="nationality" aria-describedby="nameHelp" placeholder="Enter Nationality">
				<div style="color: red; margin-bottom: 0; margin-top: 0.5em"><?php echo form_error('nationality'); ?></div>
              </div>
              <div class="col-md-6">
                <label for="exampleInputMoveInDate">Birthday</label>
                <input class="form-control" id="exampleInputMoveInDate" type="date" name="birthday" aria-describedby="nameHelp" placeholder="Enter Move In Date">
				<div style="color: red; margin-bottom: 0; margin-top: 0.5em"><?php echo form_error('birthday'); ?></div>
              </div>
            </div>
          </div>
		  <div class="form-group">
            <div class="form-row">
              <div class="col-md-6">
                <label for="exampleInputNationality">Profession/Occupation</label>
                <input class="form-control" id="exampleInputNationality" type="text"name="profession" aria-describedby="nameHelp" placeholder="Enter Profession/Occupation">
				<div style="color: red; margin-bottom: 0; margin-top: 0.5em"><?php echo form_error('profession'); ?></div>
              </div>
              <div class="col-md-6">
                <label for="exampleInputMoveInDate">Move In Date</label>
                <input class="form-control" id="exampleInputMoveInDate" type="date" name="move_in" aria-describedby="nameHelp" placeholder="Enter Move In Date">
				<div style="color: red; margin-bottom: 0; margin-top: 0.5em"><?php echo form_error('move_in'); ?></div>
              </div>
            </div>
          </div>
		  <div class="form-group">
            <div class="form-row">
              <div class="col-md-6">
                <label for="exampleInputBlock">Block</label>
                <input class="form-control" id="exampleInputBlock" type="text"name="block" aria-describedby="nameHelp" placeholder="Enter Block">
				<div style="color: red; margin-bottom: 0; margin-top: 0.5em"><?php echo form_error('block'); ?></div>
              </div>
              <div class="col-md-6">
                <label for="exampleInputLot">Lot</label>
                <input class="form-control" id="exampleInputLot" type="text" name="lot" aria-describedby="nameHelp" placeholder="Enter Lot">
				<div style="color: red; margin-bottom: 0; margin-top: 0.5em"><?php echo form_error('lot'); ?></div>
              </div>
            </div>
          </div>
		  <div class="form-group">
            <div class="form-row">
              <div class="col-md-6">
                <label for="exampleInputStreet">Street</label>
                <input class="form-control" id="exampleInputStreet" type="text" name="street" aria-describedby="nameHelp" placeholder="Enter Street">
				<div style="color: red; margin-bottom: 0; margin-top: 0.5em"><?php echo form_error('street'); ?></div>
              </div>
              <div class="col-md-6">
                <label for="exampleInputType">Type</label>
				<select class="form-control" id="exampleInputType" name="type">
					<option value="1">Homeowner</option>
					<option value="2">Tenant</option>
				</select>
				<div style="color: red; margin-bottom: 0; margin-top: 0.5em"><?php echo form_error('type'); ?></div>
              </div>
            </div>
          </div>
		  <div class="form-group">
			<div class="form-row">
                <label for="exampleInputStreet">Previous Address</label>
                <input class="form-control" id="exampleInputPrevAdd" type="text" name="prev_add" aria-describedby="nameHelp" placeholder="Enter Previous Address">
				<div style="color: red; margin-bottom: 0; margin-top: 0.5em"><?php echo form_error('prev_add'); ?></div>
			</div>
		  </div>
		  <div class="form-group">
            <div class="form-row">
              <div class="col-md-6">
                <label for="exampleInputTel">Telephone No</label>
                <input class="form-control" id="exampleInputTel" type="text" name="tel_no" aria-describedby="nameHelp" placeholder="Enter Telephone">
				<div style="color: red; margin-bottom: 0; margin-top: 0.5em"><?php echo form_error('tel_no'); ?></div>
              </div>
              <div class="col-md-6">
                <label for="exampleInputMobile">Mobile No</label>
                <input class="form-control" id="exampleInputMobile" type="text" name="mobile_no" aria-describedby="nameHelp" placeholder="Enter Mobile">
				<div style="color: red; margin-bottom: 0; margin-top: 0.5em"><?php echo form_error('mobile_no'); ?></div>
              </div>
            </div>
          </div>
          <div class="form-group">
			<div class="form-row">
              <div class="col-md-6">
                <label for="exampleInputEmail">Email Address</label>
				<input class="form-control" id="exampleInputEmail1" type="email" name="email" aria-describedby="emailHelp" placeholder="Enter email">
				<div style="color: red; margin-bottom: 0; margin-top: 0.5em"><?php echo form_error('email'); ?></div>
              </div>
              <div class="col-md-6">
				<label for="exampleInputName">Username</label>
				<input class="form-control" id="exampleInputName" type="text" name="username" aria-describedby="nameHelp" placeholder="Enter Username">
				<div style="color: red; margin-bottom: 0; margin-top: 0.5em"><?php echo form_error('username'); ?></div>
              </div>
            </div>
          </div>
		  <div class="form-group">
            <div class="form-row">
              <div class="col-md-6">
                <label for="exampleInputName">Password</label>
                <input class="form-control" id="exampleInputName" type="text" name="pw" aria-describedby="nameHelp" placeholder="Enter Username">
				<div style="color: red; margin-bottom: 0; margin-top: 0.5em"><?php echo form_error('username'); ?></div>
              </div>
              <div class="col-md-6">
                <label for="exampleInputLastName">Retype Password</label>
                <input class="form-control" id="exampleInputLastName" type="password" name="retype" aria-describedby="nameHelp" placeholder="Enter Password">
				<div style="color: red; margin-bottom: 0; margin-top: 0.5em"><?php echo form_error('retype'); ?></div>
              </div>
            </div>
          </div>
		  <br>
		  <input id="submit" class="btn btn-primary btn-block" type="submit" name="submit" value="Next">
        </form>
        <div class="text-center">
          <a class="d-block small mt-3" href="<?php echo site_url('Sorrento/index'); ?>">Login Page</a>
        </div>
      </div>
    </div>
  </div>
  <br>
  <!-- Bootstrap core JavaScript-->
  <script src="<?php echo js('vendor/jquery/jquery.min.js'); ?>"></script>
  <script src="<?php echo css('vendor/bootstrap/js/bootstrap.bundle.min.js'); ?>"></script>
  <!-- Core plugin JavaScript-->
  <script src="<?php echo js('vendor/jquery-easing/jquery.easing.min.js'); ?>"></script>
  <script src="<?php echo js('sb-admin.js'); ?>"></script>
</body>

</html>
