-- MySQL Workbench Forward Engineering

SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='TRADITIONAL,ALLOW_INVALID_DATES';

-- -----------------------------------------------------
-- Schema sorrento
-- -----------------------------------------------------

-- -----------------------------------------------------
-- Schema sorrento
-- -----------------------------------------------------
CREATE SCHEMA IF NOT EXISTS `sorrento` DEFAULT CHARACTER SET utf8 ;
-- -----------------------------------------------------
-- Schema sorrento
-- -----------------------------------------------------
USE `sorrento` ;

-- -----------------------------------------------------
-- Table `sorrento`.`users`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `sorrento`.`users` (
  `user_id` INT NOT NULL AUTO_INCREMENT,
  `user_firstName` VARCHAR(45) NOT NULL,
  `user_lastName` VARCHAR(45) NOT NULL,
  `user_nationality` VARCHAR(45) NOT NULL,
  `user_birthday` DATE NOT NULL,
  `user_profession` VARCHAR(45) NOT NULL,
  `user_moveIn` DATE NOT NULL,
  `user_block` VARCHAR(45) NOT NULL,
  `user_lot` VARCHAR(45) NOT NULL,
  `user_street` VARCHAR(45) NOT NULL,
  `user_type` VARCHAR(45) NOT NULL,
  `user_prevAdd` VARCHAR(256) NOT NULL,
  `user_telNo` VARCHAR(45) NOT NULL,
  `user_mobileNo` VARCHAR(45) NOT NULL,
  `user_email` VARCHAR(45) NOT NULL,
  `user_accountType` VARCHAR(45) NOT NULL,
  `user_username` VARCHAR(45) NOT NULL,
  `user_password` VARCHAR(45) NOT NULL,
  `user_isActive` TINYINT(1) NOT NULL,
  PRIMARY KEY (`user_id`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `sorrento`.`household_members`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `sorrento`.`household_members` (
  `household_id` INT NOT NULL AUTO_INCREMENT,
  `household_user_id` INT NOT NULL,
  `household_name` VARCHAR(128) NOT NULL,
  `household_birthday` DATE NOT NULL,
  `household_profession` VARCHAR(45) NOT NULL,
  `household_relation` VARCHAR(45) NOT NULL,
  PRIMARY KEY (`household_id`),
  INDEX `user_id_idx` (`household_user_id` ASC),
  CONSTRAINT `household_user_id`
    FOREIGN KEY (`household_user_id`)
    REFERENCES `sorrento`.`users` (`user_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `sorrento`.`fees`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `sorrento`.`fees` (
  `fee_id` INT NOT NULL AUTO_INCREMENT,
  `fee_user_id` INT NOT NULL,
  `fee_amountPaid` DECIMAL(6,2) NOT NULL,
  `fee_datePaid` VARCHAR(45) NOT NULL,
  PRIMARY KEY (`fee_id`),
  INDEX `user_id_idx` (`fee_user_id` ASC),
  CONSTRAINT `fee_user_id`
    FOREIGN KEY (`fee_user_id`)
    REFERENCES `sorrento`.`users` (`user_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `sorrento`.`announcements`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `sorrento`.`announcements` (
  `announcement_id` INT NOT NULL AUTO_INCREMENT,
  `announcement_user_id` INT NOT NULL,
  `announcement_dateAdded` DATETIME NOT NULL,
  `announcement_subject` VARCHAR(45) NOT NULL,
  `announcement_details` VARCHAR(45) NOT NULL,
  PRIMARY KEY (`announcement_id`),
  INDEX `user_id_idx` (`announcement_user_id` ASC),
  CONSTRAINT `announcement_user_id`
    FOREIGN KEY (`announcement_user_id`)
    REFERENCES `sorrento`.`users` (`user_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `sorrento`.`events`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `sorrento`.`events` (
  `event_id` INT NOT NULL AUTO_INCREMENT,
  `event_user_id` INT NOT NULL,
  `event_subject` VARCHAR(128) NOT NULL,
  `event_details` VARCHAR(256) NOT NULL,
  `event_dateFrom` DATE NOT NULL,
  `event_dateTo` DATE NOT NULL,
  `event_isActive` TINYINT(1) NOT NULL,
  PRIMARY KEY (`event_id`),
  INDEX `event_user_id_idx` (`event_user_id` ASC),
  CONSTRAINT `event_user_id`
    FOREIGN KEY (`event_user_id`)
    REFERENCES `sorrento`.`users` (`user_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `sorrento`.`reservations`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `sorrento`.`reservations` (
  `reserve_id` INT NOT NULL AUTO_INCREMENT,
  `reserve_user_id` INT NOT NULL,
  `reserve_type` VARCHAR(45) NOT NULL,
  `reserve_date` DATE NOT NULL,
  `reserve_timeFrom` TIME NOT NULL,
  `reserve_timeTo` TIME NOT NULL,
  `reserve_confirmed` TINYINT(1) NOT NULL,
  `reserve_or` VARCHAR(45) NULL,
  PRIMARY KEY (`reserve_id`),
  INDEX `user_id_idx` (`reserve_user_id` ASC),
  CONSTRAINT `reserve_user_id`
    FOREIGN KEY (`reserve_user_id`)
    REFERENCES `sorrento`.`users` (`user_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `sorrento`.`meeting_agenda`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `sorrento`.`meeting_agenda` (
  `agenda_id` INT NOT NULL AUTO_INCREMENT,
  `agenda_subject` VARCHAR(128) NOT NULL,
  `agenda_details` VARCHAR(128) NOT NULL,
  `agenda_location` VARCHAR(128) NOT NULL,
  `agenda_date` DATE NOT NULL,
  `agenda_isActive` TINYINT(1) NOT NULL,
  PRIMARY KEY (`agenda_id`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `sorrento`.`meeting_confirmations`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `sorrento`.`meeting_confirmations` (
  `confirmation_id` INT NOT NULL AUTO_INCREMENT,
  `agenda_id` INT NOT NULL,
  `confirmation_user_id` INT NOT NULL,
  `confirmation_going` VARCHAR(45) NOT NULL,
  `confirmation_reschedule` DATE NOT NULL,
  PRIMARY KEY (`confirmation_id`),
  INDEX `agenda_id_idx` (`agenda_id` ASC),
  INDEX `user_id_idx` (`confirmation_user_id` ASC),
  CONSTRAINT `agenda_id`
    FOREIGN KEY (`agenda_id`)
    REFERENCES `sorrento`.`meeting_agenda` (`agenda_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `confirmation_user_id`
    FOREIGN KEY (`confirmation_user_id`)
    REFERENCES `sorrento`.`users` (`user_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `sorrento`.`move_out`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `sorrento`.`move_out` (
  `move_out_id` INT NOT NULL AUTO_INCREMENT,
  `move_out_user_id` INT NOT NULL,
  `move_out_date` DATE NOT NULL,
  `move_out_certificate` TINYINT(1) NOT NULL,
  PRIMARY KEY (`move_out_id`),
  INDEX `user_id_idx` (`move_out_user_id` ASC),
  CONSTRAINT `move_out_user_id`
    FOREIGN KEY (`move_out_user_id`)
    REFERENCES `sorrento`.`users` (`user_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `sorrento`.`stickers`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `sorrento`.`stickers` (
  `sticker_id` INT NOT NULL AUTO_INCREMENT,
  `sticker_user_id` INT NOT NULL,
  `sticker_driver` VARCHAR(128) NOT NULL,
  `sticker_type` VARCHAR(45) NOT NULL,
  `sticker_plateNo` VARCHAR(45) NOT NULL,
  PRIMARY KEY (`sticker_id`),
  INDEX `user_id_idx` (`sticker_user_id` ASC),
  CONSTRAINT `sticker_user_id`
    FOREIGN KEY (`sticker_user_id`)
    REFERENCES `sorrento`.`users` (`user_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `sorrento`.`notifications`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `sorrento`.`notifications` (
  `notification_id` INT NOT NULL AUTO_INCREMENT,
  `notification_user_id` INT NOT NULL,
  `notification_reservation_id` INT NOT NULL,
  `notification_event_id` INT NOT NULL,
  `notification_sticker_id` INT NOT NULL,
  `notification_announcement_id` INT NOT NULL,
  `notification_agenda_id` INT NOT NULL,
  `notification_move_out_id` INT NOT NULL,
  `notifications_confirmation_id` INT NOT NULL,
  `notification_type` VARCHAR(45) NOT NULL,
  `notification_details` VARCHAR(45) NOT NULL,
  PRIMARY KEY (`notification_id`),
  INDEX `user_id_idx` (`notification_user_id` ASC),
  INDEX `notification_reservation_id_idx` (`notification_reservation_id` ASC),
  INDEX `notification_event_id_idx` (`notification_event_id` ASC),
  INDEX `notification_sticker_id_idx` (`notification_sticker_id` ASC),
  INDEX `notification_announcement_id_idx` (`notification_announcement_id` ASC),
  INDEX `notification_agenda_id_idx` (`notification_agenda_id` ASC),
  INDEX `notification_move_out_id_idx` (`notification_move_out_id` ASC),
  INDEX `notification_confirmation_id_idx` (`notifications_confirmation_id` ASC),
  CONSTRAINT `notification_user_id`
    FOREIGN KEY (`notification_user_id`)
    REFERENCES `sorrento`.`users` (`user_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `notification_reservation_id`
    FOREIGN KEY (`notification_reservation_id`)
    REFERENCES `sorrento`.`reservations` (`reserve_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `notification_event_id`
    FOREIGN KEY (`notification_event_id`)
    REFERENCES `sorrento`.`events` (`event_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `notification_sticker_id`
    FOREIGN KEY (`notification_sticker_id`)
    REFERENCES `sorrento`.`stickers` (`sticker_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `notification_announcement_id`
    FOREIGN KEY (`notification_announcement_id`)
    REFERENCES `sorrento`.`announcements` (`announcement_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `notification_agenda_id`
    FOREIGN KEY (`notification_agenda_id`)
    REFERENCES `sorrento`.`meeting_agenda` (`agenda_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `notification_move_out_id`
    FOREIGN KEY (`notification_move_out_id`)
    REFERENCES `sorrento`.`move_out` (`move_out_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `notification_confirmation_id`
    FOREIGN KEY (`notifications_confirmation_id`)
    REFERENCES `sorrento`.`meeting_confirmations` (`confirmation_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;
