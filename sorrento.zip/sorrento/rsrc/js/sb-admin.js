(function($) {
  "use strict"; // Start of use strict
  // Configure tooltips for collapsed side navigation
  $('.navbar-sidenav [data-toggle="tooltip"]').tooltip({
    template: '<div class="tooltip navbar-sidenav-tooltip" role="tooltip" style="pointer-events: none;"><div class="arrow"></div><div class="tooltip-inner"></div></div>'
  })
  // Toggle the side navigation
  $("#sidenavToggler").click(function(e) {
    e.preventDefault();
    $("body").toggleClass("sidenav-toggled");
    $(".navbar-sidenav .nav-link-collapse").addClass("collapsed");
    $(".navbar-sidenav .sidenav-second-level, .navbar-sidenav .sidenav-third-level").removeClass("show");
  });
  // Force the toggled class to be removed when a collapsible nav link is clicked
  $(".navbar-sidenav .nav-link-collapse").click(function(e) {
    e.preventDefault();
    $("body").removeClass("sidenav-toggled");
  });
  // Prevent the content wrapper from scrolling when the fixed side navigation hovered over
  $('body.fixed-nav .navbar-sidenav, body.fixed-nav .sidenav-toggler, body.fixed-nav .navbar-collapse').on('mousewheel DOMMouseScroll', function(e) {
    var e0 = e.originalEvent,
      delta = e0.wheelDelta || -e0.detail;
    this.scrollTop += (delta < 0 ? 1 : -1) * 30;
    e.preventDefault();
  });
  // Scroll to top button appear
  $(document).scroll(function() {
    var scrollDistance = $(this).scrollTop();
    if (scrollDistance > 100) {
      $('.scroll-to-top').fadeIn();
    } else {
      $('.scroll-to-top').fadeOut();
    }
  });
  // Configure tooltips globally
  $('[data-toggle="tooltip"]').tooltip()
  // Smooth scrolling using jQuery easing
  $(document).on('click', 'a.scroll-to-top', function(event) {
    var $anchor = $(this);
    $('html, body').stop().animate({
      scrollTop: ($($anchor.attr('href')).offset().top)
    }, 1000, 'easeInOutExpo');
    event.preventDefault();
  });
})(jQuery); // End of use strict

function addMembers(){
            // Number of inputs to create
            var number = document.getElementById("householdMember").value;
            // Container <div> where dynamic content will be placed
            var row = document.getElementById("row");
            var container1 = document.getElementById("container1");
            var container2 = document.getElementById("container2");
            // Clear previous contents of the container
            while (container1.hasChildNodes()) {
                container1.removeChild(container1.lastChild);
			}
            while (container2.hasChildNodes()) {
                container2.removeChild(container2.lastChild);
			}
			
            for (i=0;i<number;i++){
                // Append a node with a random text
                // Create an <input> element, set its type and name attributes
				var input1 = document.createElement("input");
                input1.type = "text";
				input1.name = "member" + (i+1);
                input1.id = "householdMemberInput";
				
				var input2 = document.createElement("input");
                input2.type = "date";
				input2.name = "birthday" + (i+1);
                input2.id = "householdMemberInput";
				
				var input3 = document.createElement("input");
                input3.type = "text";
				input3.name = "profession" + (i+1);
                input3.id = "householdMemberInput";
				
				var input4 = document.createElement("input");
                input4.type = "text";
				input4.name = "relation" + (i+1);
                input4.id = "householdMemberInput";
				
				var text1 = document.createElement("label");
				text1.appendChild(document.createTextNode("Full Name"));
				var text2 = document.createElement("label");
				text2.appendChild(document.createTextNode("Birthday"));
				var text3 = document.createElement("label");
				text3.appendChild(document.createTextNode("Profession/Occupation"));
				var text4 = document.createElement("label");
				text4.appendChild(document.createTextNode("Relation"));
				
				
                container1.appendChild(text1);
                container1.appendChild(input1);
                container1.appendChild(text2);
                container1.appendChild(input2);
                container2.appendChild(text3);
                container2.appendChild(input3);
                container2.appendChild(text4);
                container2.appendChild(input4);
                // Append a line break 
				
                container1.appendChild(document.createElement("br"));
                container2.appendChild(document.createElement("br"));
            }
        }
		
function addCar(){
            // Number of inputs to create
            var num = document.getElementById("carCount").value;
            // Container <div> where dynamic content will be placed
            var carRow = document.getElementById("carRow");
            var carContainer1 = document.getElementById("carContainer1");
            var carContainer2 = document.getElementById("carContainer2");
            var carContainer3 = document.getElementById("carContainer3");
            // Clear previous contents of the container
            while (carContainer1.hasChildNodes()) {
                carContainer1.removeChild(carContainer1.lastChild);
			}
            while (carContainer2.hasChildNodes()) {
                carContainer2.removeChild(carContainer2.lastChild);
			}
			while (carContainer3.hasChildNodes()) {
                carContainer3.removeChild(carContainer3.lastChild);
			}
			
			
			//Create array of options to be added
			var array = ["Private","Commercial"];
			
            for (i=0;i<num;i++){
                // Append a node with a random text
                // Create an <input> element, set its type and name attributes
				var input1 = document.createElement("input");
                input1.type = "text";
				input1.name = "driver_name" + (i+1);
                input1.id = "householdMemberInput";
				
				var input2 = document.createElement("input");
                input2.type = "text";
				input2.name = "plate_no" + (i+1);
                input2.id = "householdMemberInput";
				
				var input3 = document.createElement("select");
                input3.type = "text";
				input3.name = "type" + (i+1);
                input3.id = "householdMemberInput";
				
				//Create and append the options
				for (var x = 0; x < array.length; x++) {
					var option = document.createElement("option");
					option.value = array[x];
					option.text = array[x];
					input3.appendChild(option);
				}
				
				var text1 = document.createElement("label");
				text1.appendChild(document.createTextNode("Name of Driver"));
				var text2 = document.createElement("label");
				text2.appendChild(document.createTextNode("Vehicle Plate No"));
				var text3 = document.createElement("label");
				text3.appendChild(document.createTextNode("Type"));
				
				
                carContainer1.appendChild(text1);
                carContainer1.appendChild(input1);
                carContainer3.appendChild(text2);
                carContainer3.appendChild(input2);
                carContainer2.appendChild(text3);
                carContainer2.appendChild(input3);
                // Append a line break 
				
                carContainer1.appendChild(document.createElement("br"));
                carContainer2.appendChild(document.createElement("br"));
                carContainer3.appendChild(document.createElement("br"));
            }
        }