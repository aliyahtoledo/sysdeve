-- phpMyAdmin SQL Dump
-- version 4.0.4.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Apr 25, 2016 at 06:27 AM
-- Server version: 5.5.32
-- PHP Version: 5.4.19

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `realsuccess_app`
--
CREATE DATABASE IF NOT EXISTS `realsuccess_app` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `realsuccess_app`;

-- --------------------------------------------------------

--
-- Table structure for table `cust`
--

CREATE TABLE IF NOT EXISTS `cust` (
  `CID` int(11) NOT NULL AUTO_INCREMENT COMMENT 'Customer Primary Key',
  `FName` varchar(100) NOT NULL COMMENT 'First name of Customer',
  `MI` varchar(3) NOT NULL COMMENT 'Middle Initial of Customer',
  `LName` varchar(100) NOT NULL COMMENT 'Last Name of Customer',
  PRIMARY KEY (`CID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `cust_add_list`
--

CREATE TABLE IF NOT EXISTS `cust_add_list` (
  `CALID` int(11) NOT NULL AUTO_INCREMENT COMMENT 'Primary Key of Customer Address List Item',
  `CID` int(11) NOT NULL COMMENT 'Primary Key of Customer',
  `CAID` int(11) NOT NULL COMMENT 'Primary Key of Address',
  PRIMARY KEY (`CALID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `cust_cn_list`
--

CREATE TABLE IF NOT EXISTS `cust_cn_list` (
  `CCLID` int(11) NOT NULL AUTO_INCREMENT COMMENT 'Primary Key of Customer Contact Number List Item',
  `CID` int(11) NOT NULL COMMENT 'Primary Key of Customer',
  `CCID` int(11) NOT NULL COMMENT 'Primary Key of Contact Number',
  PRIMARY KEY (`CCLID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `cust_order_list`
--

CREATE TABLE IF NOT EXISTS `cust_order_list` (
  `COLID` int(11) NOT NULL AUTO_INCREMENT COMMENT 'Primary Key of Order List',
  `CID` int(11) NOT NULL COMMENT 'Customer Primary Key',
  `PID` int(11) NOT NULL COMMENT 'Product Primary Key',
  `Amount` decimal(10,2) NOT NULL COMMENT 'Amount ordered',
  `AmountUnit` varchar(10) DEFAULT 'kilo' COMMENT 'Unit for amount',
  PRIMARY KEY (`COLID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `c_address`
--

CREATE TABLE IF NOT EXISTS `c_address` (
  `CAID` int(11) NOT NULL AUTO_INCREMENT COMMENT 'Primary Key of Customer Address',
  `HouseNo` varchar(200) DEFAULT NULL COMMENT 'House Number of Customer',
  `Street` varchar(200) DEFAULT NULL COMMENT 'Street of Customer',
  `Brgy` varchar(200) DEFAULT NULL COMMENT 'Barangay of Customer',
  `City` varchar(200) DEFAULT 'Las Piñas City' COMMENT 'City of Customer',
  `Type` varchar(100) DEFAULT 'Home Address' COMMENT 'Type of Address',
  PRIMARY KEY (`CAID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `c_contactnum`
--

CREATE TABLE IF NOT EXISTS `c_contactnum` (
  `CCID` int(11) NOT NULL AUTO_INCREMENT COMMENT 'Primary Key of Contact Number',
  `Type` varchar(200) DEFAULT 'Home Phone Number' COMMENT 'Description of Contact Number',
  `AreaCode` int(11) NOT NULL COMMENT 'Area Code of Customer',
  `PhoneNum` int(11) NOT NULL COMMENT 'Phone Number of Customer',
  PRIMARY KEY (`CCID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `order`
--

CREATE TABLE IF NOT EXISTS `order` (
  `OID` int(11) NOT NULL AUTO_INCREMENT COMMENT 'Order Primary Key',
  `CID` int(11) NOT NULL COMMENT 'Customer Primary Key',
  `Date` date NOT NULL COMMENT 'Order Date',
  `Time` time DEFAULT NULL COMMENT 'Order Time',
  PRIMARY KEY (`OID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `prod_det`
--

CREATE TABLE IF NOT EXISTS `prod_det` (
  `PID` int(11) NOT NULL AUTO_INCREMENT COMMENT 'Product ID Primary Key',
  `Name` varchar(200) NOT NULL COMMENT 'Name of Product on shelf',
  `Desc` varchar(1000) DEFAULT NULL COMMENT 'Product Description',
  `Price` decimal(8,2) NOT NULL COMMENT 'Price of Product',
  `PTID` int(11) NOT NULL COMMENT 'Type of Product. Foreign Key to PROD_TYPE',
  PRIMARY KEY (`PID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `prod_type`
--

CREATE TABLE IF NOT EXISTS `prod_type` (
  `PTID` int(11) NOT NULL AUTO_INCREMENT COMMENT 'Product Type ID',
  `Name` varchar(100) NOT NULL COMMENT 'Name of Product Type',
  `Desc` varchar(1000) DEFAULT NULL COMMENT 'Description of Product Type',
  PRIMARY KEY (`PTID`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `prod_type`
--

INSERT INTO `prod_type` (`PTID`, `Name`, `Desc`) VALUES
(1, 'Grocery Item', 'This product is a grocery item, and is found in the grocery shelves'),
(2, 'Rice', 'This product is rice, and is found in the rice tills');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
